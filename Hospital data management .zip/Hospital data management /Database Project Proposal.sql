-- =============================================*
--         HOSPITAL DATABASE
-- =============================================*

CREATE DATABASE HOSPITAL;
USE HOSBITAL;

CREATE TABLE Patients (
    patient_id INT PRIMARY KEY,
    first_name VARCHAR(100),
    last_name  VARCHAR(100),
    age        INT,
    gender     VARCHAR(10),
    phone      VARCHAR(20),
    address    VARCHAR(60)
);
CREATE TABLE Doctors (
    doctor_id INT PRIMARY KEY,
    d_name  VARCHAR(100),
    specialization VARCHAR(100),
    phone VARCHAR(20)
);

CREATE TABLE Appointments (
    appointment_id   INT PRIMARY KEY,
    patient_id       INT,
    doctor_id        INT,
    appointment_date VARCHAR(100),
    status           VARCHAR(20),
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id),
    FOREIGN KEY (doctor_id)  REFERENCES Doctors(doctor_id)
);

CREATE TABLE MedicalRecords (
    record_id  INT PRIMARY KEY,
    patient_id INT,
    diagnosis  VARCHAR(40),
    treatment  VARCHAR(50),
    record_date VARCHAR(90),
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id)
);

CREATE TABLE Bills (
    bill_id      INT PRIMARY KEY,
    patient_id   INT,
    total_amount DECIMAL(10,2),
    bill_date    VARCHAR(100),
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id)
);

CREATE TABLE BillDetails (
    detail_id    INT PRIMARY KEY,
    bill_id      INT,
    service_name VARCHAR(100),
    cost         DECIMAL(10,2),
    FOREIGN KEY (bill_id) REFERENCES Bills(bill_id)
);


INSERT INTO Patients VALUES
(1, 'MOHAMMED',   'ALSAIDI',   25, 'Male',   '01065027139', 'MILANO'),
(2, 'ABDELRHMAN', 'SAEED',     24, 'Male',   '01122158264', 'PARIS'),
(3, 'ROLAA',      'HATEM',     23, 'Female', '01003090740', 'LONDON'),
(4, 'MENAA',      'MOHAMMED',  22, 'Female', '01020930532', 'ENGLAND'),
(5, 'NOGA',       'HAMADA',    21, 'Female', '01064915384', 'ROMA');

INSERT INTO Doctors VALUES
(11, 'AYA AHMED',     'Teeth',            '01065027138'),
(12, 'MERNA MOHAMED', 'Nose and ear',     '01065027137'),
(13, 'HANAN',         'Surgery',          '01065027136'),
(14, 'SOHEIR',        'physical therapy', '01065027135'),
(15, 'MARWA',         'pediatrics',       '01065027134');

INSERT INTO Appointments VALUES
(100, 1, 11, '2026-04-01 10:00:10', 'Done'),
(101, 2, 12, '2026-07-02 12:30:30', 'Pending'),
(102, 3, 13, '2026-08-03 09:15:00', 'Done'),
(103, 4, 14, '2026-09-04 02:50:20', 'Cancelled'),
(104, 5, 15, '2026-11-05 11:45:00', 'Pending');

INSERT INTO MedicalRecords VALUES
(900, 1, 'Flu',       'Medicine',      '2026-05-01 10:00:00'),
(901, 2, 'Tooth Pain','Extraction',    '2026-05-02 12:00:00'),
(902, 3, 'Headache',  'Painkillers',   '2026-05-03 09:30:00'),
(903, 4, 'Back Pain', 'Physiotherapy', '2026-05-04 11:00:00'),
(904, 5, 'Fever',     'Antibiotics',   '2026-05-05 01:00:00');

INSERT INTO Bills VALUES
(300, 1, 0, '2026-05-01'),
(301, 2, 0, '2026-05-02'),
(302, 3, 0, '2026-05-03'),
(303, 4, 0, '2026-05-04'),
(304, 5, 0, '2026-05-05');

INSERT INTO BillDetails VALUES
(600, 300, 'Checkup',        100),
(601, 300, 'X-Ray',          200),
(602, 301, 'Consultation',   150),
(603, 301, 'Medicine',        50),
(604, 302, 'Blood Test',     120),
(605, 302, 'Scan',           180),
(606, 303, 'Therapy Session',200),
(607, 304, 'Injection',       80);


UPDATE Patients
SET last_name = 'AHMED', age = 26, phone = '01500046058'
WHERE patient_id = 1;

UPDATE Doctors
SET name = 'AYA HASSAN', specialization = 'Cardiology'
WHERE doctor_id = 11;

UPDATE Doctors
SET name = 'MERNA KHTAAB', specialization = 'Teeth'
WHERE doctor_id = 12;

UPDATE Appointments
SET appointment_date = '2026-05-10 02:50:00', status = 'Done'
WHERE appointment_id = 100;

UPDATE MedicalRecords
SET diagnosis = 'Severe Flu', treatment = 'Stronger Medicine'
WHERE record_id = 900;

UPDATE Bills
SET total_amount = 300
WHERE bill_id = 300;

UPDATE BillDetails
SET service_name = 'MRI Scan'
WHERE detail_id = 600;


SELECT first_name, last_name,age  FROM Patients;
SELECT * FROM Doctors;
SELECT * FROM Appointments;
SELECT * FROM MedicalRecords;
SELECT * FROM Bills;
SELECT * FROM BillDetails;

ALTER TABLE Patients ADD email VARCHAR(100);

ALTER TABLE Doctors MODIFY phone VARCHAR(30);

ALTER TABLE Patients RENAME COLUMN phone TO patient_phone;

ALTER TABLE Patients ADD CONSTRAINT chk_age CHECK (age > 0);

ALTER TABLE Bills MODIFY bill_id INT NOT NULL;

ALTER TABLE MedicalRecords ADD medical_status VARCHAR(50);

DELETE FROM Appointments WHERE appointment_id = 103
DELETE FROM BillDetails WHERE detail_id = 607
DELETE FROM MedicalRecords WHERE record_id = 904

ALTER TABLE Patients DROP COLUMN email
ALTER TABLE MedicalRecords DROP COLUMN medical_status
-----------------------------------
------------INNER------------------
-----------------------------------
SELECT 
P.patient_id,
P.first_name,
P.last_name,
D.name AS doctor_name,
D.specialization,
A.appointment_date,
A.status
FROM Appointments A
INNER JOIN Patients P
ON A.patient_id = P.patient_id
INNER JOIN Doctors D
ON A.doctor_id = D.doctor_id;
--------------------------------------------
===========LEFT============================
--------------------------------------------
SELECT 
P.first_name,
P.last_name,
A.appointment_date
FROM Patients P
LEFT JOIN Appointments A
ON P.patient_id = A.patient_id;
----------------------------------
============RIGHT=================
----------------------------------
SELECT 
D.name,
D.specialization,
A.appointment_date
FROM Appointments A
RIGHT JOIN Doctors D
ON A.doctor_id = D.doctor_id;
------------------------------------
============FULL====================
------------------------------------
SELECT 
P.patient_id,
P.first_name,
A.appointment_id,
A.appointment_date
FROM Patients P
LEFT JOIN Appointments A
ON P.patient_id = A.patient_id

UNION

SELECT 
P.patient_id,
P.first_name,
A.appointment_id,
A.appointment_date
FROM Patients P
RIGHT JOIN Appointments A
ON P.patient_id = A.patient_id;